﻿using DATAgridEF.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DATAgridEF
{
    /// <summary>
    /// Логика взаимодействия для CovidInfo.xaml
    /// </summary>
    public partial class CovidInfo : Window
    {
        Model1 db;
        public CovidInfo()
        {
            InitializeComponent();
            /* 
             Вывод данных в datagrid
             */
            db = new Model1();
            studentCov.ItemsSource = db.Covids.ToList();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            using (Model1 context = new Model1())
            {
                /*
                 добавленние данных в таблицу Covids
                 */
                Covid covid = new Covid();
                covid.surname =sur.Text;
                covid.name = nam.Text;
                covid.patronymic = otc.Text;
                covid.group = gro.Text;
                context.Covids.Add(covid);
                context.SaveChanges();
                db = new Model1();
                studentCov.ItemsSource = db.Covids.ToList();

            }

        }

       
    }
}
