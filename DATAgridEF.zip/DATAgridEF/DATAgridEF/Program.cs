﻿using DATAgridEF.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DATAgridEF
{
    class Program
    {
        static void MainWindow (string[] args)
        {
         
        }
    }
}
